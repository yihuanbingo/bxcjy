<?php
/*
 * 定义全局变量
*/
if(!defined('IN_BS')) 
{
 die('hacking attempt');
}

$smarty->assign('client_host',CLIENT_HOST);
?>