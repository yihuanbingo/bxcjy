<?php
/*
 * 语言变量
 * author yuanjiang @2.16.2013
*/
if(!defined('IN_BS'))
{
 die('hacking attempt');
}
$_lang = array(
'title'=>'小区快帮',
);
?>