<?php
/*
 * 定义全局变量
*/
if(!defined('IN_BS')) 
{
 die('hacking attempt');
}



$smarty->assign('api_host',API_HOST);

?>