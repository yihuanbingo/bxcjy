<?php
/*
* 微信用户同步登录类
+-----------------------------
* 微信用户访问时会传递openid值
+-----------------------------
*/
if(!defined('IN_BS'))
{
  die('hacking attempt');
}

class Wx  extends Common {


   static $member_url = "https://api.weixin.qq.com/cgi-bin/user/info?";
   
   /*
    * 获取access_token
   */
   static function getAccess_token()
   {   
       $token_url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.APPID.'&secret='.APPSECRET;
       $access_token = parent::file_get($token_url);
	   $access_token = $GLOBALS['Json']->decode($access_token);  
	   return $access_token;   
   } 
   
   /*
   * 获取有效的access_token
   */
   static function setAccess_token()
   {
       $expire =  time() + 60;   //防止响应延时，access_token提前1分钟过期
       $sql = "select access_token from ".$GLOBALS['Base']->table('access_token')." where expire > $expire limit 0, 1 "; 
	   $access_token = $GLOBALS['Mysql']->getOne($sql); 
	   /* 数据库中access_token可用 */
	   if($access_token)
	   {  
	      return $access_token;
	   }    
	   /* 重新获取access_token，并保存数据库 */
       else
	   {
	      $access_token = self::getAccess_token();
		  $sql = "update ".$GLOBALS['Base']->table('access_token')." set access_token='".$access_token->access_token."', expire=".(time()+$access_token->expires_in)." ";
		  $GLOBALS['Mysql']->query($sql);
          return $access_token->access_token;  
	   }
   } 
   
   /*
   * 根据openid获取用户信息
   */
   static function getWxuserInfo($openid, $access_token)
   {
	   $url = self::$member_url."access_token=".$access_token."&openid=".$openid."&lang=zh_CN";  
	   $memberInfo = parent::file_get($url);
	   $memberInfo = $GLOBALS['Json']->decode($memberInfo);
	   return $memberInfo;
   }
   
	/*
	* 
	*/
	static function setUserInfo($openid)
	{
		$access_token = self::setAccess_token();
		$userInfo = self::getWxuserInfo($openid,$access_token);
		$data = array(
		'nickname'=>$userInfo->nickname,
		'headimgurl'=>$userInfo->headimgurl
		);
		$table = $GLOBALS['Base']->table('user');
		$where = array('openid'=>$openid);
		$GLOBALS['Mysql']->update($data,$table,$where);
	}
	
}

?>