<?php
function _urlencode($str)
{
	return rawurlencode($str);
}
?>