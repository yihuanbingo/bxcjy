<?php
$PHPSayConfig = array(
					"version"		=> "1.1 Build 415",
					"sitename"		=> "小区快帮",
					"sitemail"		=> "932625974@qq.com",
					"emailjoin"		=> 1,
					"ppsecure"		=> "20140303Dyw",
					"qqconnect"		=> array( "appid" => "", "appkey" => "" ),
					"wxconnect"		=> array( "appid" => "wx91c5fd7d0669a634", "appsecret" => "70fd10a8dfbfdb8f218e3cd4307e90ad"),
					"api_host"		=> "http://api.bangsoon.cn/",
					"www_hoat"		=> "http://xiaoqu.bangsoon.cn/",
					"bbs_host"		=> "http://api.bangsoon.cn/bbs/",
					);
?>