<?php
$PHPSayConfig = array(
					"version"		=> "1.1 Build 415",
					"sitename"		=> "小区快帮",
					"sitemail"		=> "932625974@qq.com",
					"emailjoin"		=> 1,
					"ppsecure"		=> "20140303Dyw",
					"qqconnect"		=> array( "appid" => "", "appkey" => "" ),
					"wxconnect"		=> array( "appid" => "wxc2705fbb2964ea45", "appsecret" => "866c7ca8c3ee3f50a9319ba13f78f930"),
					"api_host"		=> "http://api.bangsoon.net/",
					"www_hoat"		=> "http://property.bangsoon.net/",
					"bbs_host"		=> "http://api.bangsoon.net/bbs/",
					);
?>