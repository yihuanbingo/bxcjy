<?php
$mysql_host		= "localhost";

$mysql_user		= "root";

$mysql_pass		= "20140303Dyw";

$mysql_dbname	= "bangsoon";
?>