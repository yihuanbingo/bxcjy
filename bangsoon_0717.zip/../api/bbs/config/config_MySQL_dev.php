<?php
$mysql_host		= "112.124.119.178";

$mysql_user		= "root";

$mysql_pass		= "20140303Dyw";

$mysql_dbname	= "bangsoon";
?>