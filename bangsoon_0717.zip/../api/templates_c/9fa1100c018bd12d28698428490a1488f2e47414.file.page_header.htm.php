<?php /* Smarty version Smarty-3.1.7, created on 2014-07-09 14:35:05
         compiled from "./templates/library/page_header.htm" */ ?>
<?php /*%%SmartyHeaderCode:172270247853bce2999fbaa7-77628949%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9fa1100c018bd12d28698428490a1488f2e47414' => 
    array (
      0 => './templates/library/page_header.htm',
      1 => 1403441759,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '172270247853bce2999fbaa7-77628949',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_lang' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_53bce299a0262',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53bce299a0262')) {function content_53bce299a0262($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $_smarty_tpl->tpl_vars['_lang']->value['title'];?>
</title>
<meta name="viewport" content="width=device-width,height=device-height,maximum-scale=1.0,user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="templates/css/common.css">
<link rel="stylesheet" type="text/css" href="templates/css/user_passport.css">
<link rel="stylesheet" type="text/css" href="/templates/css/advice.css">
<script type="text/javascript" src="/templates/js/jquery-1.8.0.min.js"></script>
<script type="text/javascript" src="/templates/js/jquery.form.js"></script>
<script type="text/javascript" src="/templates/js/common.js"></script>
<script type="text/javascript" src="/templates/js/transaction.js"></script>
</head>
<body id="top">

<div id="popDiv" class="mydiv" style="display:none">
<div class="middle"><div id="alertMsg"></div></div>
</div>

<div id="bg" class="bg" style="display:none"></div>

<?php }} ?>