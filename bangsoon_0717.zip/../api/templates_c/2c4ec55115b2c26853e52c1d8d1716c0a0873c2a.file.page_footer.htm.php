<?php /* Smarty version Smarty-3.1.7, created on 2014-07-09 14:35:05
         compiled from "./templates/library/page_footer.htm" */ ?>
<?php /*%%SmartyHeaderCode:69289040953bce299a05500-08636192%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2c4ec55115b2c26853e52c1d8d1716c0a0873c2a' => 
    array (
      0 => './templates/library/page_footer.htm',
      1 => 1403441759,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '69289040953bce299a05500-08636192',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_53bce299a06f0',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53bce299a06f0')) {function content_53bce299a06f0($_smarty_tpl) {?><div class="gfooter">
© 2014 小区快帮
</div>
<div style="display:none">
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F12c7ebc0d5e268e34feb51b6c41feead' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>
</body>
</html><?php }} ?>