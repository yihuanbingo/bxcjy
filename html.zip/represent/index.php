<?php
/*
 * 小区管理员后台首页
 * author yuanjiang @2.16.2013
*/
define("IN_BS",true);
require("../includes/init.php");
require("includes/cls_represent.php");
Represent::checkUserLogin();

$act= isset($_REQUEST['act']) ? $Common->charFormat($_REQUEST['act']): 'default' ;
$community_id = $_SESSION['property']['community_id'];

/* 默认首页 */
if($act=='default')
{
   $subnum = $Mysql->getOne("select count(user_id) from ".$Base->table('user')." where community_id=$community_id and subscribe=1");
   $smarty->assign('subnum',$subnum);
}
/* 退出登录 */
elseif($act=='logout')
{
   unset($_SESSION['property']);
   $Common->base_header("Location:/represent/login\n");  
}


chdir('../');
$smarty->display("represent/index.htm");

?>