<?php
/*
 * 语言变量
 * author yuanjiang @2.16.2013
*/
if(!defined('IN_BS'))
{
 die('hacking attempt');
}
$_lang = array(
'title'=>'小区快帮',
);

$_lang['year'] = array(2015,2014,2013,2012,2011,2010,2009,2008);
$_lang['month'] = array(1,2,3,4,5,6,7,8,9,10,11,12);
?>