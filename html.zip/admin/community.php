<?php
/*
 * 小区管理
 * author yuanjiang @2.16.2013
*/
define("IN_BS",true);

require("../includes/init.php");
require('includes/cls_admin.php');
Admin::checkAdminLogin();

$act = isset($_REQUEST['act']) ? $Common->charFormat($_REQUEST['act']): 'list' ;
$aid = $_SESSION['admin']['aid'];

/* 小区列表 */
if($act=='list')
{
   $pageNow = isset($_REQUEST['page']) ? intval($_REQUEST['page']): 1 ;
   $pageNum = 50;
   $list = Admin::getCommunityList($pageNow, $pageNum);
   $smarty->assign('list',$list);
}
/* 切换到物业后台 */
elseif($act=='switch')
{
   $cid = isset($_REQUEST['cid']) ? intval($_REQUEST['cid']) : 0 ;
   if($cid>0)
   {
      $row = $Mysql->getRow("select community_id, account from ".$Base->table('community')." where community_id=$cid ");
	  if($row)
	  {
	     /* 小区存在，则直接赋值，并跳转 */
	     $_SESSION['property'] = $row;
		 $Common->base_header("Location:/property\n");
	  }
	  else
	  {
	     die('hacking attempt!');
	  }
   }
}

$smarty->assign('act',$act);
$smarty->assign('nav','community');
chdir('../');
$smarty->display("admin/community.htm");

?>